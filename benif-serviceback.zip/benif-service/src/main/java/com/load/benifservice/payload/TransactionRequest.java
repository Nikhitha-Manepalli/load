package com.load.benifservice.payload;

import lombok.Data;

@Data
public class TransactionRequest {
	
	private int senderAccountNumber;
	
	private int receiverAccountNumber;
	
	private int amount;
	
	private int pin;

	public TransactionRequest(int senderAccountNumber, int receiverAccountNumber, int amount, int pin) {
		super();
		this.senderAccountNumber = senderAccountNumber;
		this.receiverAccountNumber = receiverAccountNumber;
		this.amount = amount;
		this.pin=pin;
	}

	public TransactionRequest() {
		super();
	}
	
	

}
