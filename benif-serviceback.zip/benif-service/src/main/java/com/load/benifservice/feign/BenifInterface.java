package com.load.benifservice.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.load.benifservice.entity.Beneficiary;
import com.load.benifservice.entity.Transaction;
import com.load.benifservice.entity.User;
import com.load.benifservice.payload.BeneficiaryRequest;
import com.load.benifservice.payload.BeneficiaryUpdate;
import com.load.benifservice.payload.NewTransactionRequest;
import com.load.benifservice.payload.Response;
import com.load.benifservice.payload.UserRequest;

@FeignClient(name = "BENIFICIARY")
public interface BenifInterface {

	@PostMapping("beneficiaries")
	
	 public void addBeneficiary(@RequestBody BeneficiaryRequest req);

@GetMapping("beneficiaries/benlist")
public List<Beneficiary> getAllBeneficiary() ;

@PutMapping("beneficiaries/{id}")
public void updateBenefi (@PathVariable int id, @RequestBody BeneficiaryUpdate req) ;

@DeleteMapping("beneficiaries/{id}")
public void delete(@PathVariable int id) ;

@PostMapping("users/login")
public ResponseEntity<User> loginUser (@RequestBody User userData);

@PostMapping
public void addUser(@RequestBody UserRequest req) ;

@DeleteMapping("users/{id}")
public void deleteUser(@PathVariable int id) ;

@GetMapping("users/history")
public List<Transaction> getAllTransactions();

@PutMapping("users/{id}")
public void updateUser(@RequestBody UserRequest req, @PathVariable int id) ;

 @PostMapping("users/txn")
 public Response transact(@RequestBody NewTransactionRequest req) ;



}
