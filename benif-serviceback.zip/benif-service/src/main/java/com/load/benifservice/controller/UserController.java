package com.load.benifservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.load.benifservice.entity.Transaction;
import com.load.benifservice.entity.User;
import com.load.benifservice.feign.BenifInterface;
import com.load.benifservice.payload.NewTransactionRequest;
import com.load.benifservice.payload.Response;
import com.load.benifservice.payload.UserRequest;




@RestController
@RequestMapping("/users")
@CrossOrigin("*")
public class UserController {
	
	private BenifInterface service;
	
	
    
	@Autowired
	public UserController(BenifInterface service) {
		super();
		this.service = service;
	}

	@PostMapping("/login")
	public ResponseEntity<User> loginUser (@RequestBody User userData){
		return service.loginUser(userData);
	}

	@PostMapping
	public void addUser(@RequestBody UserRequest req) {
		 service.addUser(req);
	}
	
	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable int id) {
		service.delete(id);
	}
	
	@GetMapping("/history")
    public List<Transaction> getAllTransactions(){
    	return service.getAllTransactions();    }
	
	@PutMapping("/{id}")
	public void updateUser(@RequestBody UserRequest req, @PathVariable int id) {
		service.updateUser(req, id);
	}
	
	 @PostMapping("/txn")
	 public Response transact(@RequestBody NewTransactionRequest req) {
		 return service.transact(req);
	 }

}
