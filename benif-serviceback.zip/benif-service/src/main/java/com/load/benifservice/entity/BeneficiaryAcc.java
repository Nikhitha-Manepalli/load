package com.load.benifservice.entity;


import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
public class BeneficiaryAcc {
	
	private int benAccId;
	
	
	private int benAccountNumber;
	
	@NotNull
	private int benBalance=0;
	
	

	public BeneficiaryAcc(int benAccId, @NotNull int benAccountNumber, @NotNull int benBalance) {
		super();
		this.benAccId = benAccId;
		this.benAccountNumber = benAccountNumber;
		this.benBalance = benBalance;
	}



	public BeneficiaryAcc() {
		super();
	}
	
	
	
}
