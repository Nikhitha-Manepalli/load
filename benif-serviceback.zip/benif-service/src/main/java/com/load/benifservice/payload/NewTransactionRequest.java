package com.load.benifservice.payload;

import lombok.Data;

@Data
public class NewTransactionRequest {
	
	private int userId;
	
	private int senderAccountNumber;

	private String senderName;
	
	private int receiverAccountNumber;
	
	private String receiverName;
	
	private int amount;
	
	private int pin;

	public NewTransactionRequest(int userId,int senderAccountNumber, String senderName, int receiverAccountNumber, String receiverName,
			int amount, int pin) {
		super();
		this.userId = userId;
		this.senderAccountNumber = senderAccountNumber;
		this.senderName = senderName;
		this.receiverAccountNumber = receiverAccountNumber;
		this.receiverName = receiverName;
		this.amount = amount;
		this.pin = pin;
	}

	public NewTransactionRequest() {
		super();
	}
	
	
	
	
}
