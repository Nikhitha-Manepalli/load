package com.load.benifservice.payload;

import lombok.Data;

@Data
public class BeneficiaryUpdate {

	private int id;
private String beneficiarName;
	
	private String bankName;
	
	private String branch;
	
	private String paymentMethod;
	
	private int mobilenum;
	
	private int benAccountNumber;

	public BeneficiaryUpdate(String beneficiarName, String bankName, String branch, String paymentMethod, int mobilenum,
			int benAccountNumber) {
		super();
		this.beneficiarName = beneficiarName;
		this.bankName = bankName;
		this.branch = branch;
		this.paymentMethod = paymentMethod;
		this.mobilenum = mobilenum;
		this.benAccountNumber = benAccountNumber;
	}

	public BeneficiaryUpdate() {
		super();

	}
	
}
