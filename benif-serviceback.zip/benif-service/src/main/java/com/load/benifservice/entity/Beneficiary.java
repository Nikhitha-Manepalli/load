package com.load.benifservice.entity;


import java.sql.Timestamp;

import jakarta.validation.constraints.NotNull;
import lombok.Data;



@Data
public class Beneficiary {
	
	
	
	private int id;
	
	
	private String beneficiarName;
	
	@NotNull
	private String bankName;
	
	@NotNull
	private String branch;
	
	@NotNull
	private String paymentMethod;
	
	@NotNull
	private int mobilenum;
	
	private Timestamp lastUpdated;
	
	
	private Timestamp createdAt;
	
	
	private BeneficiaryAcc beneficiaryAcc;
	
	
	

	public Beneficiary(int id, String beneficiarName, @NotNull String bankName,
			@NotNull String branch, @NotNull String paymentMethod, @NotNull int mobilenum, BeneficiaryAcc beneficiaryAcc) {
		super();
		this.id = id;
		this.beneficiarName = beneficiarName;
		this.bankName = bankName;
		this.branch = branch;
		this.paymentMethod = paymentMethod;
		this.mobilenum= mobilenum;
		this.beneficiaryAcc=beneficiaryAcc;
	}

	
	

	public Beneficiary() {
		super();
	}

}
