package com.load.benifservice.entity;

import java.sql.Timestamp;

import lombok.Data;


@Data
public class Transaction {
	
	
    private int transactionId;

    private int senderAccountNumber;
    
    private String senderName;
    
    private int receiverAccountNumber;
    
    private String receiverName;
    
    private int amount;

   
    private Timestamp createdAt;

	public Transaction(int transactionId, int senderAccountNumber, String senderName, int receiverAccountNumber,
			String receiverName, int amount, Timestamp createdAt) {
		super();
		this.transactionId = transactionId;
		this.senderAccountNumber = senderAccountNumber;
		this.senderName = senderName;
		this.receiverAccountNumber = receiverAccountNumber;
		this.receiverName = receiverName;
		this.amount = amount;
		this.createdAt = createdAt;
	}

	public Transaction() {
		super();

	}
    
    

}
