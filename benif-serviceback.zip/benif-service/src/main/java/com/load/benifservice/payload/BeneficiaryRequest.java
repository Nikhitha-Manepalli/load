package com.load.benifservice.payload;

import lombok.Data;

@Data
public class BeneficiaryRequest {
	
private int id;
	
	private String beneficiarName;
	
	private String bankName;
	
	private String branch;
	
	private String paymentMethod;
	
	private int mobilenum;
	
	private int benAccountNumber;
	
	private int benBalance=0;

	public BeneficiaryRequest(int id, String beneficiarName, String bankName, String branch, String paymentMethod,
			int mobilenum, int benAccountNumber, int benBalance) {
		super();
		this.id = id;
		this.beneficiarName = beneficiarName;
		this.bankName = bankName;
		this.branch = branch;
		this.paymentMethod = paymentMethod;
		this.mobilenum = mobilenum;
		this.benAccountNumber = benAccountNumber;
		this.benBalance = benBalance;
	}

	public BeneficiaryRequest() {
		super();
	}
	
	
	

}
