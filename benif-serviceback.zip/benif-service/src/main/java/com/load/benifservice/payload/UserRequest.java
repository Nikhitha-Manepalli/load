package com.load.benifservice.payload;


import lombok.Data;

@Data
public class UserRequest {
	
	private int id;
	
	private String email;
	
	private String username;
	
	private String password;
	
	private int userAccountNumber;
	
	private int userBalance=50000;
	
	private int pin;

	public UserRequest(int id, String email, String username, String password, int userAccountNumber, int userBalance,
			int pin) {
		super();
		this.id = id;
		this.email = email;
		this.username = username;
		this.password = password;
		this.userAccountNumber = userAccountNumber;
		this.userBalance = userBalance;
		this.pin = pin;
	}

	public UserRequest() {
		super();
	}
	
	
}
