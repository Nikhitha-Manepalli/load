package com.load.benifservice.entity;

import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
public class User {
	
	
	private int userId;
	
	
	private String email;
	
	@NotNull
	private String username;
	
	@NotNull
	private String password;
	
	
	private UserAcc userAcc;

	public User() {
		super();
		
	}

	public User(int userId, String email, @NotNull String password, @NotNull String username, UserAcc userAcc) {
		super();
		this.userId = userId;
		this.email = email;
		this.password = password;
		this.username = username;
		this.userAcc = userAcc;
	}

}
