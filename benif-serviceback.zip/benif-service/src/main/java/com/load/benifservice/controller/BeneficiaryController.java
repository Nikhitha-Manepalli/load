package com.load.benifservice.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.load.benifservice.entity.Beneficiary;
import com.load.benifservice.feign.BenifInterface;
import com.load.benifservice.payload.BeneficiaryRequest;
import com.load.benifservice.payload.BeneficiaryUpdate;




@RestController
@RequestMapping("/beneficiaries")
@CrossOrigin("*")
public class BeneficiaryController {
	  private static final Logger logger = LogManager.getLogger(BeneficiaryController.class);
	private BenifInterface beneficiaryService;
	
	
	@Autowired
	public BeneficiaryController(BenifInterface beneficiaryService) {
		super();
		this.beneficiaryService = beneficiaryService;
	}

	@PostMapping
		
		 public void addBeneficiary(@RequestBody BeneficiaryRequest req) {
		        // Your implementation here
		        // Process the beneficiaryRequest and return an appropriate response
		        
		beneficiaryService.addBeneficiary(req);
	}
	
	@GetMapping("/benlist")
	public List<Beneficiary> getAllBeneficiary() {
		return beneficiaryService.getAllBeneficiary();
	}
	
	
	@PutMapping("/{id}")
	public void updateBenefi (@PathVariable int id, @RequestBody BeneficiaryUpdate req) {
		
	    logger.info("Received update request for Beneficiary with ID: {}", id);
	    beneficiaryService.updateBenefi(id, req);
	}

	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable int id) {
		beneficiaryService.delete(id);
	}

	
	
}
