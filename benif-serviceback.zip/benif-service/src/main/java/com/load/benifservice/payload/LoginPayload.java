package com.load.benifservice.payload;

import lombok.Data;

@Data
public class LoginPayload {
	
	private String username;
	private String password;
	private int id;
	private String email;
	public LoginPayload(String username, String password, int id, String email) {
		super();
		this.username = username;
		this.password = password;
		this.id = id;
		this.email = email;
	}
	public LoginPayload() {
		super();

	}
	
	

}
