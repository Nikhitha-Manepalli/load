package com.load.benifservice.entity;

import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
public class UserAcc {
	
	
	private int userAccId;
	
	@NotNull
	private int userAccountNumber;
	
	@NotNull
	private int userBalance=50000;
	
	@NotNull
	private int pin;

	public UserAcc(int userAccId, @NotNull int userAccountNumber, @NotNull int userBalance, @NotNull int pin) {
		super();
		this.userAccId = userAccId;
		this.userAccountNumber = userAccountNumber;
		this.userBalance = userBalance;
		this.pin = pin;
	}

	public UserAcc() {
		super();
	
	}

	
	
}
