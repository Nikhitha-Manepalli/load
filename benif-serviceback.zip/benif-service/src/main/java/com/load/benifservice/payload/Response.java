package com.load.benifservice.payload;

import lombok.Data;

@Data
public class Response {
	
	private String message;
	 
	 
	 
	public Response() {
		super();
 
	}
 
	public Response(String message) {
		super();
		this.message = message;
	}

}
