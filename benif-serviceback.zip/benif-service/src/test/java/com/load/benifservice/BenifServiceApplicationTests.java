package com.load.benifservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenifServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
